	
<?php

header("Access-Control-Allow-Origin: *");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
		$command = escapeshellcmd('python3 /opt/lampp/htdocs/backend.py');

		$output = shell_exec($command);
		echo $output;
		
	}


?>

