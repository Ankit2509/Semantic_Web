manage.py


for Django 

allows backend.py and ruleEngine.py to communicate to the frontend  a.html and mainpage,html