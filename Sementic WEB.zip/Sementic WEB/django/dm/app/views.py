from django.shortcuts import render, render_to_response

# Create your views here.
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_protect, csrf_exempt

import json
import os

from . import backend
from . import ruleEngine
from . import static

def index(request):
	return render_to_response('main_page.html')

def rule(request):
	return render_to_response('a.html')


@csrf_exempt
def GetData(request):
	print("*"*20)
	rule = json.loads(request.POST.get("rule"))
	print(rule)
	# ret = {"hi": "hello"}
	ret = backend.Main(rule)
	return HttpResponse(json.dumps(ret))

@csrf_exempt
def SetData(request):
	print("*"*20)
	# ret = {"hi": "hello"}
	ret = backend.Main()
	return HttpResponse(json.dumps(ret)) 

@csrf_exempt
def GetDataRule(request):
	print("getting data rules")
    # data={"items":[{"subject":"Tabu","predicate":"Acted_In","object":"?movie","connector":"AND"},{"subject":"Akshay_Kumar","predicate":"Acted_In","object":"?movie","connector":"OR"},{"subject":"Amit_Sharma","predicate":"isDirectorOf","object":"?movie","connector":"AND"},{"subject":"?director","predicate":"isDirectorOf","object":"Andhadhun","connector":"THEN"},{"subject":"?movie","predicate":"willHaveRating","object":"Low","connector":"0"}]}
	data = json.loads(request.POST.get("data"))
	print(data, type(data))
	print("="*10)
	retsubject, predicate, objecti = ruleEngine.Main(data)
	ret = {}
	ret['sub'] = retsubject
	ret['obj'] = objecti
	ret['pred'] = predicate
	print("-"*10)
	print(ret)
	return HttpResponse(json.dumps(ret))

@csrf_exempt
def GetDataRuleInitial(request):
	ret = {}
	actors, directors, predicates, movies = ruleEngine.Initial()
	ret['actors'] = actors
	ret['directors'] = directors
	ret['predicates'] = predicates
	ret['movies'] = movies
	return HttpResponse(json.dumps(ret))