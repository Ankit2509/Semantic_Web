from django.urls import path

from . import views

urlpatterns = [
    path('getDataRuleInitial/', views.GetDataRuleInitial, name='get initial data from rule-engine'),
    path('getDataRule/', views.GetDataRule, name='get data from rule-engine'),
    path('getData/', views.GetData, name='get data'),
    path('setData/', views.SetData, name='set data'),
    path('userRules/', views.rule, name='rule'),
    path('', views.index, name='index'),
]