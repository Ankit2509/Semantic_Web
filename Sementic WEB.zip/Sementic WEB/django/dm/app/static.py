
from neo4j import GraphDatabase
import json

def Main(prop):
	uri="bolt://localhost:7687"
	driver = GraphDatabase.driver(uri, auth=("neo4j", "1234"))
	db=driver.session()


	actors="match(y:owl__Class)-[:rdfs__subClassOf]->(x:owl__Class{rdfs__label:'Actors'}) return y.rdfs__label as Actors"
	directors="match(y:owl__Class)-[:rdfs__subClassOf]->(x:owl__Class{rdfs__label:'Directors'}) return y.rdfs__label as Directors"
	movie="match(y:owl__Class)-[:rdfs__subClassOf]->(x:owl__Class{rdfs__label:'Movie'}) return y.rdfs__label as Movie"
	predicates="match(y:owl__ObjectProperty) return y.rdfs__label as predicates"


	data1=db.run(actors)
	data2=db.run(directors)
	data3=db.run(movie)
	data4=db.run(predicates)

	db.close()

	act=[]
	dire=[]
	mov=[]
	pred=[]
	for record in data1:
	    act.append(record["Actors"])
	    
	for record in data2:
	    dire.append(record["Directors"])
	    
	for record in data1:
	    mov.append(record["Movie"])
	    
	for record in data1:
	    pred.append(record["predicates"])
	    
	    
	    
	data={}
	js=[]
	dictn={}
	data["actors"]=act
	data["directors"]=dire
	data["movies"]=mov
	data["predicates"]=pred
	js.append(data)
	dictn["res"]=js
	
	return dictn
    
    
    
    
    
    
    
    
    
    
    
    
    